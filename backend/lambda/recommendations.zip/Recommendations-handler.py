import json
import boto3

client = boto3.client("bedrock-runtime", region_name="us-west-2")

def lambda_handler(event, context):
    prompt = event["prompt"]

    response = client.invoke_model(
        modelId="us.amazon.nova-micro-v1:0",
        contentType="application/json",
        accept="application/json",
        body=json.dumps({
            "messages": [{"role": "user", "content": [{"text": prompt}]}]
        }),
    )

    body = json.loads(response["body"].read())
    text = body["output"]["message"]["content"][0]["text"].strip()

    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]

    return json.loads(text)
